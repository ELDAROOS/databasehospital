from flask import Flask, render_template, request, redirect, url_for
import psycopg2

app = Flask(__name__)
@app.route('/admin')
def admin_dashboard():
    tables = [
        'patients', 'doctors', 'doctorspecialties', 'visits',
        'electronicmedicalrecord', 'insurance', 'prescriptions',
        'medicalhistory', 'medicaltests', 'surgeries',
        'vaccinations', 'allergies', 'appointments',
        'accounts', 'medications', 'vitalsigns'
    ]
    return render_template('admin_dashboard.html', tables=tables)

@app.route('/admin_login')
def admin_login():
    return render_template('admin_login.html') 
@app.route('/logout', methods=['POST'])
def logout():
    return redirect(url_for('index'))

@app.route('/')
def index():
    return render_template('index.html')
    
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        try:
            connection = psycopg2.connect(
                user="postgres",
                password="123",
                host="78.141.227.124",
                port="5432",
                database="hospital"
            )
            cursor = connection.cursor()

            sql_query = "SELECT * FROM accounts WHERE email = %s AND password_hash = %s"
            cursor.execute(sql_query, (email, password))

            user = cursor.fetchone()

            cursor.close()
            connection.close()
            
            if user:
                return redirect(url_for('welcome'))
            else:
                return "Invalid email or password"

        except psycopg2.Error as e:
            print(f"Error: Unable to log in\n{e}")
            return "Error during login"

    return render_template('login.html')



@app.route('/welcome')
def welcome():
    return render_template('welcome.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        phone_number = request.form['phone_number']
        full_name = request.form['full_name']
        password_hash = request.form['password_hash']

        try:
            connection = psycopg2.connect(
                user="postgres",
                password="123",
                host="78.141.227.124",
                port="5432",
                database="hospital"
            )

            cursor = connection.cursor()

            check_query = "SELECT * FROM accounts WHERE email = %s OR phone_number = %s"
            cursor.execute(check_query, (email, phone_number))
            existing_user = cursor.fetchone()

            if existing_user:
                return "User with this email or phone number already exists. Please use different credentials."

            insert_query = "INSERT INTO accounts (username, email, phone_number, full_name, password_hash) VALUES (%s, %s, %s, %s, %s)"
            cursor.execute(insert_query, (username, email, phone_number, full_name, password_hash))

            connection.commit()

            cursor.close()
            connection.close()

            return redirect(url_for('welcome'))
        except psycopg2.Error as e:
            print(f"Error: Unable to register\n{e}")
            return "Error during registration"

    return render_template('register.html')

def execute_query(query, params=None):
    connection = None
    cursor = None
    result = None

    try:
        connection = psycopg2.connect(
                user="postgres",
                password="123",
                host="78.141.227.124",
                port="5432",
                database="hospital"
            )
        cursor = connection.cursor()
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        if query.upper().startswith("SELECT"):
            result = cursor.fetchall()
        cursor.execute(query)
        cursor.execute("SELECT * FROM doctorspecialties;")

        if query.upper().startswith("SELECT"):
            result = cursor.fetchall()

        connection.commit()

    except psycopg2.Error as e:
        print(f"Error executing query: {e}")

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

    return result

@app.route('/another_endpoint', methods=['GET', 'POST'])
def another_index():
    result = None

    if request.method == 'POST':
        query = request.form['query']
        result = execute_query(query)

    return render_template('terminal_test.html', result=result)
###
@app.route('/add_patient', methods=['GET', 'POST'])
def add_patient():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        date_of_birth = request.form['date_of_birth']
        address = request.form['address']
        phone = request.form['phone']
        gender = request.form['gender']

        insert_query = "INSERT INTO patients (first_name, last_name, date_of_birth, address, phone, gender) VALUES (%s, %s, %s, %s, %s, %s)"
        params = (first_name, last_name, date_of_birth, address, phone, gender)
        execute_query(insert_query, params)

        return redirect(url_for('patients_list'))

    return render_template('add_patient.html')

@app.route('/patients_list')
def patients_list():
    select_query = "SELECT * FROM patients"
    patients = execute_query(select_query)

    return render_template('patients_list.html', patients=patients)

@app.route('/add_doctor', methods=['GET', 'POST'])
def add_doctor():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        specialization = request.form['specialization']
        contact_info = request.form['contact_info']

        query = "INSERT INTO doctors (first_name, last_name, specialization, contact_info) VALUES (%s, %s, %s, %s)"
        params = (first_name, last_name, specialization, contact_info)

        execute_query(query, params)

        return redirect(url_for('index'))

    return render_template('add_doctor.html')
@app.route('/doctor_list')
def doctor_list():
    select_query = "SELECT * FROM doctors"
    patients = execute_query(select_query)
    return render_template('doctor_list.html')

@app.route('/add_specialty', methods=['GET', 'POST'])
def add_specialty():
    if request.method == 'POST':
        specialty_name = request.form['specialty_name']

        query = "INSERT INTO doctorspecialties (specialty_name) VALUES (%s)"
        params = (specialty_name,)

        execute_query(query, params)

        return redirect(url_for('specialty_list'))

    return render_template('add_specialty.html')
@app.route('/specialty_list')
def specialty_list():
    query = "SELECT * FROM doctorspecialties"
    specialties = execute_query(query)

    return render_template('specialty_list.html', specialties=specialties)
###
@app.route('/add_allergy_from')
def add_allergy_from(): 
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        allergen_name = request.form['allergen_name']
        description = request.form['description']

        sql_query = "INSERT INTO allergies (patient_id, allergen_name, description) VALUES (%s, %s, %s) RETURNING *"
        params = (patient_id, allergen_name, description)

        try:
            connection = psycopg2.connect(
                user="postgres",
                password="123",
                host="78.141.227.124",
                port="5432",
                database="hospital"
            )

            with connection.cursor() as cursor:
                cursor.execute(sql_query, params)
                new_allergy = cursor.fetchone()
                connection.commit()

            return render_template('allergy_added.html', allergy=new_allergy)

        except psycopg2.Error as e:
            print(f"Error: Unable to add allergy\n{e}")
            return "Error during allergy addition"

        finally:
            if connection:
                connection.close()

    return render_template('add_allergy_form.html')
@app.route('/allergy_added')
def allergy_added():
    
    return render_template('allergy_added.html')
##
def connect_to_db():
    return psycopg2.connect(
        user="postgres",
        password="123",
        host="78.141.227.124",
        port="5432",
        database="hospital"
    )

@app.route('/add_appointment', methods=['GET', 'POST'])
def add_appointment():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        doctor_id = request.form['doctor_id']
        appointment_datetime = request.form['appointment_datetime']
        diagnosis = request.form['diagnosis']
        prescriptions = request.form['prescriptions']

        connection = connect_to_db()
        cursor = connection.cursor()

        try:
            sql = "INSERT INTO appointments (patient_id, doctor_id, appointment_datetime, diagnosis, prescriptions) VALUES (%s, %s, %s, %s, %s) RETURNING appointment_id"
            cursor.execute(sql, (patient_id, doctor_id, appointment_datetime, diagnosis, prescriptions))
            appointment_id = cursor.fetchone()[0]

            connection.commit()

            return f"Appointment added with ID: {appointment_id}"
        except Exception as e:
            connection.rollback()
            return f"Error adding appointment: {str(e)}"
        finally:
            cursor.close()
            connection.close()

    else:
        return render_template('add_appointment.html')

@app.route('/appointments_list')
def appointments_list():
    connection = connect_to_db()
    cursor = connection.cursor()

    try:
        query = "SELECT * FROM appointments"
        cursor.execute(query)
        appointments = cursor.fetchall()
        return render_template('appointments_list.html', appointments=appointments)
    except Exception as e:
        return f"Error fetching appointments: {str(e)}"
    finally:
        cursor.close()
        connection.close()
###
@app.route('/add_electronicmedicalrecord', methods=['GET', 'POST'])
def add_electronicmedicalrecord():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        text_description = request.form['text_description']

        record_creation_date = datetime.now()

        sql_query = "INSERT INTO electronicmedicalrecord (patient_id, record_creation_date, text_description) VALUES (%s, %s, %s)"
        params = (patient_id, record_creation_date, text_description)

        execute_query(sql_query, params)

        return redirect(url_for('electronicmedicalrecord_list'))

    return render_template('add_electronicmedicalrecord.html')

@app.route('/electronicmedicalrecord_list')
def electronicmedicalrecord_list():
    sql_query = "SELECT * FROM electronicmedicalrecord"
    
    records = execute_query(sql_query)

    return render_template('electronicmedicalrecord_list.html', records=records)
####
@app.route('/add_insurance', methods=['GET', 'POST'])
def add_insurance():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        insurance_company_name = request.form['insurance_company_name']
        policy_number = request.form['policy_number']
        expiration_date = request.form['expiration_date']

        try:
            query = "INSERT INTO insurance (patient_id, insurance_company_name, policy_number, expiration_date) VALUES (%s, %s, %s, %s)"
            params = (patient_id, insurance_company_name, policy_number, expiration_date)

            execute_query(query, params)

            return redirect(url_for('insurance_list'))

        except psycopg2.Error as e:
            print(f"Error: Unable to add insurance record\n{e}")

    return render_template('add_insurance.html')

@app.route('/insurance_list')
def insurance_list():
    try:
        query = "SELECT * FROM insurance"
        records = execute_query(query)

        return render_template('insurance_list.html', records=records)

    except psycopg2.Error as e:
        print(f"Error: Unable to fetch insurance records\n{e}")

    return render_template('insurance_list.html', records=[])
####
@app.route('/add_medicalhistory', methods=['GET', 'POST'])
def add_medicalhistory():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        record_date = request.form['record_date']
        symptom_description = request.form['symptom_description']
        test_results = request.form['test_results']
        doctor_notes = request.form['doctor_notes']
        doctor_id = request.form['doctor_id']
        diagnosis = request.form['diagnosis']
        treatment = request.form['treatment']

        insert_query = "INSERT INTO medicalhistory (patient_id, record_date, symptom_description, test_results, doctor_notes, doctor_id, diagnosis, treatment) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
        execute_query(insert_query, (patient_id, record_date, symptom_description, test_results, doctor_notes, doctor_id, diagnosis, treatment))

        return redirect(url_for('index'))

    return render_template('add_medicalhistory.html')

@app.route('/medicalhistory_list')
def medicalhistory_list():
    select_query = "SELECT * FROM medicalhistory"
    records = execute_query(select_query)

    return render_template('medicalhistory_list.html', records=records)
###
@app.route('/add_medicaltest', methods=['GET', 'POST'])
def add_medicaltest():
    if request.method == 'POST':
        test_name = request.form['test_name']
        test_date = request.form['test_date']
        results = request.form['results']

        try:
            connection = psycopg2.connect(
                user="postgres",
                password="123",
                host="78.141.227.124",
                port="5432",
                database="hospital"
            )

            cursor = connection.cursor()

            insert_query = "INSERT INTO medicaltests (test_name, test_date, results) VALUES (%s, %s, %s)"
            cursor.execute(insert_query, (test_name, test_date, results))

            connection.commit()

            cursor.close()
            connection.close()

            return redirect(url_for('medicaltest_list'))
        except psycopg2.Error as e:
            print(f"Error: Unable to add medical test\n{e}")
            return "Error during adding medical test"

    return render_template('add_medicaltest.html')

@app.route('/medicaltest_list')
def medicaltest_list():
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="123",
            host="78.141.227.124",
            port="5432",
            database="hospital"
        )

        cursor = connection.cursor()

        select_query = "SELECT * FROM medicaltests"
        cursor.execute(select_query)
        tests = cursor.fetchall()

        cursor.close()
        connection.close()

        return render_template('medicaltest_list.html', tests=tests)
    except psycopg2.Error as e:
        print(f"Error: Unable to fetch medical tests\n{e}")
        return "Error during fetching medical tests"
###
@app.route('/add_medication', methods=['GET', 'POST'])
def add_medication():
    if request.method == 'POST':
        medication_name = request.form['medication_name']
        description = request.form['description']
        manufacturer = request.form['manufacturer']
        dosage = request.form['dosage']
        dosage_form = request.form['dosage_form']
        route_of_administration = request.form['route_of_administration']

        try:
            insert_query = "INSERT INTO medications (medication_name, description, manufacturer, dosage, dosage_form, route_of_administration) VALUES (%s, %s, %s, %s, %s, %s)"
            execute_query(insert_query, (medication_name, description, manufacturer, dosage, dosage_form, route_of_administration))

            return redirect(url_for('medication_list'))

        except Exception as e:
            print(f"Error adding medication: {e}")

    return render_template('add_medication.html')

@app.route('/medication_list')
def medication_list():
    try:
        select_query = "SELECT * FROM medications"
        medications = execute_query(select_query)

        return render_template('medication_list.html', medications=medications)

    except Exception as e:
        print(f"Error fetching medication list: {e}")

    return render_template('medication_list.html', medications=[])



#####
@app.route('/add_prescription', methods=['GET', 'POST'])
def add_prescription():
    if request.method == 'POST':
        doctor_id = request.form['doctor_id']
        patient_id = request.form['patient_id']
        medication_id = request.form['medication_id']
        dosage = request.form['dosage']
        instructions = request.form['instructions']
        prescription_date = request.form['prescription_date']

        try:
            query = """
                INSERT INTO prescriptions (doctor_id, patient_id, medication_id, dosage, instructions, prescription_date)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            execute_query(query, (doctor_id, patient_id, medication_id, dosage, instructions, prescription_date))
            return redirect(url_for('prescription_list'))

        except Exception as e:
            print(f"Error adding prescription: {e}")

    return render_template('add_prescription.html')

@app.route('/prescription_list')
def prescription_list():
    try:
        query = "SELECT * FROM prescriptions"
        prescriptions = execute_query(query, fetch_all=True)
        return render_template('prescription_list.html', prescriptions=prescriptions)

    except Exception as e:
        print(f"Error fetching prescriptions: {e}")

###
@app.route('/add_surgery', methods=['GET', 'POST'])
def add_surgery():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        surgery_date = request.form['surgery_date']
        surgery_name = request.form['surgery_name']
        surgeon = request.form['surgeon']
        description = request.form['description']
        medical_history_id = request.form['medical_history_id']

        try:
            connection = psycopg2.connect(
                user="postgres",
                password="123",
                host="78.141.227.124",
                port="5432",
                database="hospital"
            )

            cursor = connection.cursor()

            insert_query = "INSERT INTO surgeries (patient_id, surgery_date, surgery_name, surgeon, description, medical_history_id) VALUES (%s, %s, %s, %s, %s, %s)"
            cursor.execute(insert_query, (patient_id, surgery_date, surgery_name, surgeon, description, medical_history_id))

            connection.commit()

            cursor.close()
            connection.close()

            return redirect(url_for('surgery_list'))

        except psycopg2.Error as e:
            print(f"Error: Unable to add surgery\n{e}")
            return "Error during surgery addition"

    return render_template('add_surgery.html')

@app.route('/surgery_list')
def surgery_list():
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="123",
            host="78.141.227.124",
            port="5432",
            database="hospital"
        )

        cursor = connection.cursor()

        select_query = "SELECT * FROM surgeries"
        cursor.execute(select_query)
        surgeries = cursor.fetchall()

        cursor.close()
        connection.close()

        return render_template('surgery_list.html', surgeries=surgeries)

    except psycopg2.Error as e:
        print(f"Error: Unable to fetch surgery list\n{e}")
        return "Error fetching surgery list"
###
@app.route('/add_vaccination', methods=['GET', 'POST'])
def add_vaccination():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        vaccine_name = request.form['vaccine_name']
        vaccination_date = request.form['vaccination_date']
        dosage = request.form['dosage']

        try:
            connection = psycopg2.connect(
                user="postgres",
                password="123",
                host="78.141.227.124",
                port="5432",
                database="hospital"
            )

            cursor = connection.cursor()

            insert_query = "INSERT INTO vaccinations (patient_id, vaccine_name, vaccination_date, dosage) VALUES (%s, %s, %s, %s)"
            cursor.execute(insert_query, (patient_id, vaccine_name, vaccination_date, dosage))

            connection.commit()

            cursor.close()
            connection.close()

            return redirect(url_for('vaccination_list'))
        except psycopg2.Error as e:
            print(f"Error: Unable to add vaccination\n{e}")
            return "Error during adding vaccination"

    return render_template('add_vaccination.html')

@app.route('/vaccination_list')
def vaccination_list():
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="123",
            host="78.141.227.124",
            port="5432",
            database="hospital"
        )

        cursor = connection.cursor()

        select_query = "SELECT * FROM vaccinations"
        cursor.execute(select_query)

        vaccinations = cursor.fetchall()

        cursor.close()
        connection.close()

        return render_template('vaccination_list.html', vaccinations=vaccinations)
    except psycopg2.Error as e:
        print(f"Error: Unable to fetch vaccination data\n{e}")
        return "Error during fetching vaccination data"
###
@app.route('/add_visit', methods=['GET', 'POST'])
def add_visit():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        visit_date = request.form['visit_date']
        visit_description = request.form['visit_description']
        results = request.form['results']

        insert_query = "INSERT INTO visits (patient_id, visit_date, visit_description, results) VALUES (%s, %s, %s, %s)"
        execute_query(insert_query, (patient_id, visit_date, visit_description, results))

        return redirect(url_for('visit_list'))

    return render_template('add_visit.html')

@app.route('/visit_list')
def visit_list():
    select_query = "SELECT * FROM visits"
    visits = execute_query(select_query)

    return render_template('visit_list.html', visits=visits)
####
@app.route('/add_vitalsigns', methods=['GET', 'POST'])
def add_vitalsigns():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        measurement_datetime = request.form['measurement_datetime']
        temperature = request.form['temperature']
        blood_pressure = request.form['blood_pressure']
        pulse = request.form['pulse']
        weight = request.form['weight']
        height = request.form['height']

        try:

            check_patient_query = "SELECT * FROM patients WHERE patient_id = %s"
            patient_exists = execute_query(check_patient_query, (patient_id,), fetchall=True)

            if not patient_exists:
                return "Patient with this ID does not exist."

            insert_query = "INSERT INTO vitalsigns (patient_id, measurement_datetime, temperature, blood_pressure, pulse, weight, height) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            execute_query(insert_query, (patient_id, measurement_datetime, temperature, blood_pressure, pulse, weight, height))

            return redirect(url_for('vitalsigns_list'))

        except psycopg2.Error as e:
            print(f"Error adding vital signs: {e}")
            return "Error adding vital signs."

    return render_template('add_vitalsigns.html')

@app.route('/vitalsigns_list')
def vitalsigns_list():
    try:
        select_query = "SELECT * FROM vitalsigns"
        vital_signs = execute_query(select_query, fetchall=True)

        return render_template('vitalsigns_list.html', vital_signs=vital_signs)

    except psycopg2.Error as e:
        print(f"Error fetching vital signs: {e}")
        return "Error fetching vital signs."
###
if __name__ == '__main__':
    app.run(debug=True)
    
    